<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Web357test
 * @subpackage mod_web357_random_recipe
 * @author     Web357 Dev <careers@web357.com>
 * @copyright  2025 Web357.com
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseDriver;

class ModWeb357RandomRecipeHelper
{
    /**
     * Get a random recipe from the database
     *
     * @return object|null
     */
    public static function getRandomRecipe()
    {
        // Get the database connection
        $db = Factory::getContainer()->get(DatabaseDriver::class);

        // Define the query to fetch a random recipe
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__web357test_recipes')) // Getting Random recipe from database
            ->where($db->quoteName('state') . ' = 1')
            ->order('RAND()')
            ->setLimit(1);

        // Execute the query
        $db->setQuery($query);
        
        try {
            return $db->loadObject(); // Fetch a single recipe
        } catch (Exception $e) {
            return null;
        }
    }
}
