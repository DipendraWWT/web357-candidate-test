<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Web357test
 * @author     Web357 Dev <careers@web357.com>
 * @copyright  2025 Web357.com
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use Joomla\CMS\Component\ComponentHelper;

$params = ComponentHelper::getParams('com_web357test');

if ($recipe) { ?>
    <div class="random-recipe">
    <div>
        <p class="recipe-title-wrap">
            <strong>Title: </strong>
            <a href="<?php echo Route::_('index.php?option=com_web357test&view=recipe&id='.(int) $recipe->id); ?>">
                <?php echo $recipe->title; ?>
            </a>
        </p>
        <p class="difficulty-main-wrap">
            <strong>Difficulty: </strong> 
            <?php 
                $difficulty_array = ["easy" => 1, "medium" => 2, "hard" => 3];
                $difficulty_icon = isset($difficulty_array[$recipe->difficulty]) ? $difficulty_array[$recipe->difficulty] : 0;
                echo '<span class="hidden">' . htmlspecialchars($recipe->difficulty) . '</span>';

                for ($i = 0; $i < $difficulty_icon; $i++) {
                    echo '<i class="fa fa-star" aria-hidden="true"></i>';
                }
            ?>
        </p>
        <p class="recipe-desc-wrap"><strong>Description: </strong> <?php echo $recipe->description;?></p>
    </div>
<?php
} else {
    echo '<span>' . JText::_('MOD_WEB357_RANDOM_RECIPE_NO_RECIPE') . '</span>';
}
?>
